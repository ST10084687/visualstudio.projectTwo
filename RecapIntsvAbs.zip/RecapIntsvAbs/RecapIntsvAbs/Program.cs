﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecapIntsvAbs
{
    class Program
    {
        /*Abstract classes 
         * methods can be abstract or have implementation 
         * must have atleast one abstract method -- method without body
         * can have properties / fields / variables
         * can have access specifiers
         * not full abstraction && dosent allow you to create an obkect
         
         * Interfaces
         * can only have abstract methods
         * cant have properties / fields / variables
         * defaults to public
         * 
         */

        static void Main(string[] args)
        {

            MainStudent ms = new MainStudent();
            ms.someMessage();
            ms.secondMessage();
        }
    }
    public abstract class student
    {
        //methods
        public void someMessage()
        {
            Console.WriteLine("Normal methods in abs class");
        }
        public abstract void secondMessage();

    
}
    public class MainStudent : student
    {
        //main class to make use of the abstract class 
        //and its methods
        //HAVE TO USE the abstract method 

        public override void secondMessage ()
        {
            Console.WriteLine("Printing from the abstract method second message");
        }
    }
}
