using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebAppTwo.Pages
{
    public class aboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
