﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdvancedMethods
{
    public class Program
    {
        static void Main(string[] args)
        {
            // passes by --> value parameters --> pointing to diff memory locations 
                         // the operations of one variable WILL NOT affect the other
            //passes by --> reference (ref) parameters
            //passes by --> out parameters
            // passes by --> reference (ref) parameters
            /* Rules for using REF keyword
             * ref must be in the method header
             * When calling the method ref is pulled again
             * the ops of one variable affects the other - not seperate
             * they are both pointing to the SAME memory location
             */


            // passes by --> out parameters
            /*
             * When you want a method to return more than 1 value
             * keyword to use --> out
             * use out in the method header
             * when calling the method use out to allo multiple outputs
            */

            Console.WriteLine(" Advanced methods in c# >>>");

            
            int a = 100;
            //call the method
            passByValue(a);
            Console.WriteLine("The value of the item is: " + a);

            
            //call the method
            passByRef( ref a);
            Console.WriteLine("The value of the item is: " + a);


            //variable
            int total = 0;
            int product = 0;

            doCalcs(200, 800, out total, out product);

            Console.WriteLine("Sum = {0} && Product ={1} ", total, product);

            Console.ReadLine();
        }
        public static void passByValue(int b)
        {
            b = 500;
        }
        public static void passByRef(ref int b)
        {
            b=500;
        }
        //method
       public static void doCalcs (int a, int b, out int total, out int product)
        {
            total = a + b;
            product = a * b;
        }


    }
}
