﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsThree
{
    public class Student
    {
        // first name / last name / student id
        public string firstName { get; set; }

        public string lastName { get; set; }

        public int studentID { get; set; }

    }
}


