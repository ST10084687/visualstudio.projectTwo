﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsThree
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // create a List <T>
            // create an object of the List collections class
            // you dont have to specify the size of the list

            // List of integers 
            List<int> someList = new List<int>();


            // adding items --> use the object
            someList.Add(45);
            someList.Add(300);
            someList.Add(234);
            someList.Add(789);
            someList.Add(985);

            //List of strings
            List<string> someStrings = new List<string>();
            someStrings.Add("John");
            someStrings.Add("Sue");
            someStrings.Add("Henry");
            someStrings.Add("Jake");
            someStrings.Add("Paul");




            Console.WriteLine("Program using List<T>'s");
            Console.WriteLine("The list of integers >>>>");

            foreach (int i in someList)
            {
                Console.WriteLine(i);
            
            
            
            }

            Console.WriteLine();
            Console.WriteLine("The list of strings >>>>");
            // print out the list of strings
            foreach (string s in someStrings)
            {
                Console.WriteLine(s);
            }
            Console.WriteLine();
            // create a list of students --> from the class
            List <Student> studentList = new List<Student>()
            {
                new Student { firstName = "Henry", lastName = "Smith", studentID = 1234},
                new Student { firstName = "Sally", lastName = "Menkins", studentID = 5445},
                new Student { firstName = "Jenny", lastName = "Doe", studentID = 565},
                new Student { firstName = "Jake", lastName = "Paul", studentID = 78894 }
            };
            Console.WriteLine("Printing from student class variables >>>> ");
            foreach(Student st in studentList)

            {
                Console.WriteLine("First name: {0}, Last name {1}, Student id: {2}",
                    st.firstName, st.lastName, st.studentID);

                   
            }





            Console.ReadLine();

        }
    }
}

