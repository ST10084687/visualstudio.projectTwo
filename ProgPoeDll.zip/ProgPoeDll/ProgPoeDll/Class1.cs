﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgPoeDll
{
    public class Class1
    {
        public int selfStudyHoursCalculation(int credits, int classHours, int semesterWeeks)
        {
            int selfStudyHoursPerWeek;

            selfStudyHoursPerWeek = (int)Math.Round(((double)(credits * 10) / semesterWeeks) - classHours, MidpointRounding.AwayFromZero);

            return selfStudyHoursPerWeek;
        }
        public int hoursCalc( int selfStudyHoursPerWeek, int classHours)
        {
           // int hoursSpentThisWeek = 0;
            int hoursRemaining;
            hoursRemaining = selfStudyHoursPerWeek - classHours;
            return hoursRemaining;
        }

        public class courseInformation
        {


            public string courseName { get; set; }
            public string courseCode { get; set; }
            public int credits { get; set; }
            public int classHours { get; set; }
            public int semesterWeeks { get; set; }
            public int selfStudyHoursPerWeek { get; set; }
            public int hoursRemaining { get; set; }
          //  public int hoursSpentThisWeek { get; set; }



            public courseInformation(string courseName, string courseCode, int credits, int classHours, int semesterWeeks, int selfStudyHoursPerWeek)
            {
                this.courseName = courseName;
                this.courseCode = courseCode;
                this.credits = credits;
                this.classHours = classHours;
                this.semesterWeeks = semesterWeeks;
                this.selfStudyHoursPerWeek = selfStudyHoursPerWeek;

               
            }

            public courseInformation() { }
        }
        public class semesterInput
        {


            public int day { get; set; }
            public int month { get; set; }
            public string code { get; set; }
            public int hoursWorked { get; set; }
            public DateTime startDate { get; set; }
            public string name { get; set; }

            public semesterInput(int day, int month, string code, int hoursWorked, DateTime startDate, string name)
            {
                this.day = day;
                this.month = month;
                this.code = code;
                this.hoursWorked = hoursWorked;
                this.startDate = startDate;
                this.name = name;
            }
            public semesterInput() { }
        }
    }
}

