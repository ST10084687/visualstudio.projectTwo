﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace DemoWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window

    {

        // create an object of DispatcherTimer
        //import threading
        DispatcherTimer dt = new DispatcherTimer();
        public MainWindow()
        {
            InitializeComponent();
            /* -- new eventhandler
             *  -- set the timer interval
             *  -- start the timer
             */
            dt.Tick += new EventHandler(dt_Tick);
            dt.Interval = new TimeSpan(0, 0, 7);
            dt.Start();

        }

        private void dt_Tick(object? sender, EventArgs e)
        {
            // control the event
            Landing land = new Landing(); // the page you want next
            land.Show(); // sets visibility
            dt.Stop(); //stops the timer
            this.Close(); //closes the splash screen
        }
    }
}
