﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicInput
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // get input from the user

            // variables
            string name;
            String surname;
            string city;
            int age;

            //housekeeping
            Console.WriteLine("***Program to take user input***");

     

            //request name
            Console.WriteLine("Enter your name >>>");
            name = Console.ReadLine();

            

            //request surname
            Console.WriteLine("Enter your surname >>>");
            surname = Console.ReadLine();

            

            //request city
            Console.WriteLine("Enter your city >>>");
            city = Console.ReadLine();

            

            //request age
            Console.WriteLine("Enter your age >>>");
            // conversions --> Parse
            age = Int32.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine("THANKS FOR YOUR INPUT!!!");

            Console.ReadLine();

        }
    }
}
