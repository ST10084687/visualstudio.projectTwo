﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritanceOne
{
    public class Employees
    {
        // base class
        public string firstName;
        public string lastName;
        public string emailId;
        public int employeeNumber;

        //method

        public virtual void printInfo()
        {

            // virtual vs override 
            Console.WriteLine("Sitting in the base class>>>>>>>>>>");


        }
    }
}
