﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace inheritanceOne
{
    class Program
    {
        public static void Main(string[] args)
        {
            /* Inheritance --- multiple classes -- reuse the same code 
             * java --> sign / keyword --> extends && interface --> implements
             * Notation difference --> 
             * -- Base/ parent class --> main objs
             * -- child/ derived  classes --> use those objs ++ new objs
             * -- pure inheritance --> obj of the base class inst allowed 
             * -- objs can create --> derived class
             */

            FullTimeEmployees ft = new FullTimeEmployees();
            ft.firstName = "Jake";
            ft.lastName = "Paul";
            ft.emailId = "jake@gmail.com";
            ft.employeeNumber = 554;  
            ft.lunch = "Chicken";

            //output
            Console.WriteLine("Details of a full time employee >>>>>" +
                "\n First Name: " + ft.firstName +
                "\n Last Name: " + ft.lastName +
                 "\n EmailID: " + ft.emailId +
                 "\n Employee Number: " + ft.employeeNumber +
                 "\n Lunch: " + ft.lunch);

            // pull part time employee --> user provides values
            PartTimeEmployees pt = new PartTimeEmployees();
            Console.WriteLine("Enter your first name >>>>>>>>");
            pt.firstName = Console.ReadLine();

            Console.WriteLine("Enter your last name >>>>>>>>");
            pt.lastName = Console.ReadLine();

            Console.WriteLine("Enter email ID >>>>>>>>");
            pt.emailId = Console.ReadLine();

            Console.WriteLine("Enter your employee number >>>>>>>>");
            pt.employeeNumber = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Details of a part time employee >>>>>" +
               "\n" + ft.firstName +
               "\n" + ft.lastName +
                "\n" + ft.emailId + 
                "\n" + ft.employeeNumber +
                "\n" + ft.lunch);
           




            Console.ReadLine();
        }
    }
}
