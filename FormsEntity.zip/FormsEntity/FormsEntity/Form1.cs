﻿using FormsEntity.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormsEntity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            bindGridView();
        }
        int id = 0;
        // create objects of the classes
        Student s = new Student();
        DatabaseContext databaseContext = new DatabaseContext();
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //method
        public void bindGridView()
        {
            dataGridView2.DataSource = databaseContext.Students.ToList<Student>();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //get the values from the various design objects
            s.Name = textBox1.Text;
            s.Gender = comboBox1.SelectedItem.ToString();
            s.Age = Convert.ToInt32(textBox2.Text);
            s.Campus = textBox3.Text;

            //how to add this into the db
            databaseContext.Students.Add(s);
            int value = databaseContext.SaveChanges();

            if (value > 0)
            {
                MessageBox.Show("Your data has been inserted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information );
                bindGridView();
            }else
            {
                MessageBox.Show("Failed to insert data", "Failed", MessageBoxButtons.OK,MessageBoxIcon.Error );
            }



        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            s.Id = id;
            s.Name = textBox1.Text;
            s.Gender= comboBox1.SelectedItem.ToString();
            s.Age = Convert.ToInt32(textBox2.Text);
            s.Campus= textBox3.Text;
            databaseContext.Entry(s).State = System.Data.Entity.EntityState.Modified;
            int value = databaseContext.SaveChanges();
            if (value > 0)
            {
                MessageBox.Show("Your data has been updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                bindGridView();
            }
            else
            {
                MessageBox.Show("Failed to update data", "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView2.SelectedRows[0].Cells[0].Value);
            s = databaseContext.Students.Where(x => x.Id == id).FirstOrDefault();
            textBox1.Text = s.Name;
            comboBox1.SelectedItem = s.Gender;
            textBox2.Text = s.Age.ToString();
            textBox3.Text=s.Campus;
            

        }

        void ClearAll()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            comboBox1.SelectedItem = null;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to delete data? ","Permission",MessageBoxButtons.YesNo,MessageBoxIcon.Warning);   
            if (result == DialogResult.Yes)
            {
                s = databaseContext.Students.Where(x => x.Id == id).FirstOrDefault();
                databaseContext.Entry(s).State = System.Data.Entity.EntityState.Deleted;
                int value = databaseContext.SaveChanges();
                if (value > 0)
                {
                    MessageBox.Show("Your data has been DELETED", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    bindGridView();

                }
                else
                {
                    MessageBox.Show("Failed to DELETE data", "Failed",
                        MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                ClearAll();

            }
            else
            {
                MessageBox.Show("Delete option has been cancelled");
            }
        }
    }
}
