﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormsEntity.Model
{
    public class DatabaseContext : DbContext
    {

        /*Steps -->
         * -- inherit from the db context class
         * -- create a set of the model class
         * -- using generics list <T>
         * -- add the gets and sets
         */

        public DbSet <Student> Students { get; set; }
    }
}
