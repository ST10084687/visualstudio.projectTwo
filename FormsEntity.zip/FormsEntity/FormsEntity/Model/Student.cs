﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormsEntity.Model
{
    public class Student
    {
        // this is the table
        // cols --> id/ name / gender / age / campus

        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string Campus { get; set; }
        

        
    }
}
