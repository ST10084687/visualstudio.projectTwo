﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace poe
{
     class Program
    {
        public static void Main(string[] args)
        {
            PartTimeEmployees pt = new PartTimeEmployees();
            Console.WriteLine("Enter your first name >>>>>>>>");
            pt.firstName = Console.ReadLine();

            Console.WriteLine("Enter your last name >>>>>>>>");
            pt.lastName = Console.ReadLine();

            Console.WriteLine("Enter email ID >>>>>>>>");
            pt.emailId = Console.ReadLine();

            Console.WriteLine("Enter your employee number >>>>>>>>");
            pt.employeeNumber = Convert.ToInt32(Console.ReadLine());
        }
    }
}
