﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextFilesOne
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //open file dialog
            //browse for the file
            //create an object open file dialog

            OpenFileDialog fd = new OpenFileDialog();
            fd.ShowDialog();

            //select the file
            // copy the path of that file into the textbox
            textBox1.Text = fd.FileName;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //
            MessageBox.Show("Gayyy?","Text File", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // code to read from the text file
            // using the path of the file
            //create an object of stream reader

            StreamReader reader = new StreamReader(textBox1.Text);

            // place into the rich textbox

            richTextBox1.Text = reader.ReadToEnd();
            // close the stream
            reader.Close();
        }
    }
}
