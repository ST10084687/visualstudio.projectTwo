﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecapOOP
{
    public class Orders
    {
        private string orderID;
        private string customerName;
        private int noOfBurgers;
        private int noOfDrinks;

        //same steps as to create a constructor but select encapsulation and use property
        public string OrderID { get => orderID; set => orderID = value; }
        public string CustomerName { get => customerName; set => customerName = value; }
        public int NoOfBurgers { get => noOfBurgers; set => noOfBurgers = value; }
        public int NoOfDrinks { get => noOfDrinks; set => noOfDrinks = value; }

        // to create constructor highlight Order, right click and select quick actions and refrencing and select constructor

         public Orders(string orderID, string customerName, int noOfBurgers, int noOfDrinks)
         {
         this.orderID = orderID;
         this.customerName = customerName;
         this.noOfBurgers = noOfBurgers;
          this.noOfDrinks = noOfDrinks;
         }

        //gain access using gets and sets

        public override string ToString()
            // to generate overidem same steps as a constructor but dont select hash
        {
            Console.WriteLine("Your order details are as follows >>>>> ");
            return this.OrderID + "\n" +
                this.CustomerName + "\n" +
                this.NoOfBurgers + "\n" +
                this.NoOfDrinks;

        }


        //access ? -- gets and sets --> constructor




    }
}
