﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecapOOP
{
     class Program
    {
        static void Main(string[] args)
        {
            /* OOP Concepts
             * -- Inheritance --> other classes and objects
             * -- Polymorphism --> same name -- variables , methods
             * -- Encapsulation --> all the code behaves as a single object 
             * -- Abstraction --> abstract classes and abstract methods 
              
             */

            
            
            
            //instantiate the class
           // Orders ord = new Orders("Ord100", "John", 5, 6);

            //Orders ord = new Orders();
            //ord.OrderID = "12345";
            //ord.CustomerName = "Jack";
            //ord.NoOfBurgers = 5;
            //ord.NoOfDrinks = 3;

            //request the values from the user
            Console.WriteLine("Enter your order ID >>>>");
            string orders = Console.ReadLine();

            Console.WriteLine("Enter the customer name >>>>");
            string name = Console.ReadLine();

            Console.WriteLine("Enter the number of burgers >>>>");
            int burgers = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the number of drinks >>>>");
            int drinks = Convert.ToInt32(Console.ReadLine());

            Orders ord = new Orders(orders, name, burgers, drinks);
            Console.WriteLine(ord.ToString());


            Console.ReadLine();

            
        }
    }
}
