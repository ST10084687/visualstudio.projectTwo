﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            /*var data type -- at runtime allocates the data type
             *  -- once the data type is defined you cannot change its type
             *  dynamic simply has no idea what is being saved
             *   -- wont give any suggestions
             *   -- only figures it out when you hit run
             *   -- CAN BE CHANGED
             */

            var age = 30;
            // variables --> change its value on the fly
            // age = "45"; 

            Console.WriteLine(age);
            Console.WriteLine(age.GetType());


            // fix --> data type to change and value to change 
            // code a dynamic 
            Console.WriteLine("Using the dynamic data type >>>>>>>>");

            dynamic value = 50;
            Console.WriteLine(value);
            Console.WriteLine(value.GetType());


            // once its created it can be changed into another DT
            value = 13.75;
            Console.WriteLine(value);
            Console.WriteLine(value.GetType());

            value = "Jake";
            Console.WriteLine(value);
            Console.WriteLine(value.GetType());




            Console.ReadLine(); 
        }
    }
}
