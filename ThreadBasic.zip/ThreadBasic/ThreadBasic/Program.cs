﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadBasic
{
    class Program
    {
        static void Main(string[] args)
        {

            //Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("Loading . . . . ");
            
            
            //count backwards
            for (int i = 3; i > 0 ; i--)
            {
                Console.Write(i + " ");
              Thread.Sleep(1000);
            }

            Console.WriteLine("\n \n==================================");
            Console.WriteLine("Welcome to Budget Planner App");
            Console.WriteLine("==================================");
            Thread.Sleep(1000); //MAX 5000


            Console.ReadLine();

        }
    }
}
