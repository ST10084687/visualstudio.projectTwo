﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BasicMethods
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Basic methods
            // Static methods --> classname.methodname  || methodname   (|| means or)
            // Non Static methods --> create an object of the class

            Console.WriteLine("Basic methods --> Static and non static");

            // ways to call a static method 
            Program.firstMethod();
            // alternative
            firstMethod();

            // non static method 

            Program p = new Program ();
            p.secondMethod();

            // pulling the return methods
            firstValues(50, 25);
            firstValues(4455, 845);
            firstValues(8845, 4225);
            firstValues(5555, 1236);



            Console.ReadLine();

        }   


        public static void firstMethod()
        {
            Console.WriteLine("Just a string message >>>");
                }

        public void secondMethod()
        {
            Console.WriteLine("From the non static method >>> ");
        }

        // paramatized method
        public static int firstValues( int a, int b)
        {
            // must return statement
            int sum = a + b;
            Console.WriteLine("The values added is: " + sum);
            return sum;

        }
    }
}
