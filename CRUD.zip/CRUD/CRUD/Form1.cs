﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // sql base connection
        SqlConnection sqlConnection = new SqlConnection(@"Data Source=LAPTOP-KA1DP2CP\SQLEXPRESS;Integrated Security=True");
        //variable
        public int cityID;

        //method --> pulls and shows most recent data in the table
        private void GetCityData()
        {
            SqlCommand sqlCommand = new SqlCommand("Select * from CityTable", sqlConnection);
            DataTable dataTable = new DataTable();
            sqlConnection.Open();



            // then read from it
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            dataTable.Load(sqlDataReader);
            sqlConnection.Close();


            //pass into the gridview
            dataGridView1.DataSource = dataTable;

        }
            private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet1.CityTable' table. You can move, or remove it, as needed.
            this.cityTableTableAdapter.Fill(this.dataSet1.CityTable);
            // TODO: This line of code loads data into the 'dataSet1.CityTable' table. You can move, or remove it, as needed.
            this.cityTableTableAdapter.Fill(this.dataSet1.CityTable);

        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand sqlCommand = new SqlCommand("INSERT INTO CityTable VALUES (@City, @Min, @Max, @Wind)", sqlConnection);
            sqlCommand.CommandType = CommandType.Text;
            sqlCommand.Parameters.AddWithValue("@City", textBox2.Text);
            sqlCommand.Parameters.AddWithValue("@Min", textBox3.Text);
            sqlCommand.Parameters.AddWithValue("@Max", textBox4.Text);
            sqlCommand.Parameters.AddWithValue("@Wind", textBox5.Text);
            sqlConnection.Open();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();

            //NOTIFICATION
            MessageBox.Show("Data Inserted into DB >>>>>> ");

            //TEST
            GetCityData();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            //update button

            if(cityID > 0)
            {
                //sql cmd

                SqlCommand sqlCommand = new SqlCommand("UPDATE CityTable SET City =@City, Min =@Min, Max =@Max, Wind =@Wind WHERE ID =@ID", sqlConnection);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@City", textBox2.Text);
                sqlCommand.Parameters.AddWithValue("@Min", textBox3.Text);
                sqlCommand.Parameters.AddWithValue("@Max", textBox4.Text);
                sqlCommand.Parameters.AddWithValue("@Wind", textBox5.Text);
                sqlCommand.Parameters.AddWithValue("@ID", this.cityID);


                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();


                MessageBox.Show("Entry has been updated");
                GetCityData(); // read back from the updated table


            }
            
                else
            {
                MessageBox.Show("Failed to update the entry");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            cityID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();





        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (cityID > 0)
            {
                SqlCommand  sqlCommand = new SqlCommand("DELETE FROM CityTable WHERE Id = @ID",sqlConnection);
                sqlCommand.CommandType = CommandType.Text;
                sqlCommand.Parameters.AddWithValue("@ID", this.cityID);
                sqlConnection.Open();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();


                MessageBox.Show("Entry has been deleted");
                GetCityData();

            }else
            {
                MessageBox.Show("Could not delete the entry");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = '';
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
