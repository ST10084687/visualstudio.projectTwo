﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplicationLogin.Data;
using WebApplicationLogin.Data.Models;

namespace WebApplicationLogin.Pages.Movies
{
    public class IndexModel : PageModel
    {
        private readonly WebApplicationLogin.Data.ApplicationDbContext _context;

        public IndexModel(WebApplicationLogin.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Movie> Movie { get;set; }

        public async Task OnGetAsync()
        {
            Movie = await _context.Movie.ToListAsync();
        }
    }
}
